/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "youtube-pfp.png",
    "revision": "472c9b311647f89d7bc24daa6f8b84bf"
  }, {
    "url": "youtube-pfp-transparent.png",
    "revision": "9eef73e66265c4b9eb5d26d20dd606ec"
  }, {
    "url": "ribbon.png",
    "revision": "b73f3d8403a86724da84ca2e3748e063"
  }, {
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "85f389f5546cbb6b05f2ab8d646d6383"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4d8070be81f812699e982f91979cedad"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3ef3104b528531564566879bf602d167"
  }, {
    "url": "index.html",
    "revision": "a4e1f8a5fbda9e7f5392e7a509b7ae51"
  }, {
    "url": "icon.svg",
    "revision": "78798bf706d35d827abc98b981f2a3c6"
  }, {
    "url": "icon.ico",
    "revision": "c63697aa7f63e392c880d3b7bd177cf4"
  }, {
    "url": "favicon.ico",
    "revision": "c63697aa7f63e392c880d3b7bd177cf4"
  }, {
    "url": "book.png",
    "revision": "8a4d770998b23fc683b4ad60185ec63c"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "a91f7baaa5005a9999670512a79d922e"
  }, {
    "url": "app-icon.png",
    "revision": "8a4d770998b23fc683b4ad60185ec63c"
  }, {
    "url": "app-icon.ico",
    "revision": "c63697aa7f63e392c880d3b7bd177cf4"
  }, {
    "url": "assets/vendor-react-B3d5dUz8.js",
    "revision": null
  }, {
    "url": "assets/vendor-lucide-C2-nnCSz.js",
    "revision": null
  }, {
    "url": "assets/vendor-firebase-7XxliRMG.js",
    "revision": null
  }, {
    "url": "assets/mockGames-Cz0dQuRa.js",
    "revision": null
  }, {
    "url": "assets/index-BMVLCMuD.css",
    "revision": null
  }, {
    "url": "assets/index-BJqxk6AS.js",
    "revision": null
  }, {
    "url": "assets/UpdateRequiredModal-BuM8IHCn.js",
    "revision": null
  }, {
    "url": "assets/SettingsModal-BCs8A_RQ.js",
    "revision": null
  }, {
    "url": "assets/RenameModal-BW6flCZN.js",
    "revision": null
  }, {
    "url": "assets/QuickGameSearchModal-DlD9rUI-.js",
    "revision": null
  }, {
    "url": "assets/PlaythroughNotepad-Q2iMWg3Q.js",
    "revision": null
  }, {
    "url": "assets/PersonalQuestsModal-BBHpAeb1.js",
    "revision": null
  }, {
    "url": "assets/PaywallModal-CAgIUrhk.js",
    "revision": null
  }, {
    "url": "assets/MagicalBookIcon-CrV07ZMA.js",
    "revision": null
  }, {
    "url": "assets/GameScreenModal-Cyyds5Xv.js",
    "revision": null
  }, {
    "url": "assets/GameGuidesBrowser-DUgtF87t.js",
    "revision": null
  }, {
    "url": "assets/DesktopLogin-C2_tL_oy.js",
    "revision": null
  }, {
    "url": "assets/BetaFeedbackModal-BnNAo84J.js",
    "revision": null
  }, {
    "url": "assets/AuthModal-D8RVteSS.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "a91f7baaa5005a9999670512a79d922e"
  }, {
    "url": "favicon.ico",
    "revision": "c63697aa7f63e392c880d3b7bd177cf4"
  }, {
    "url": "icon.svg",
    "revision": "78798bf706d35d827abc98b981f2a3c6"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3ef3104b528531564566879bf602d167"
  }, {
    "url": "pwa-512x512.png",
    "revision": "4d8070be81f812699e982f91979cedad"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "85f389f5546cbb6b05f2ab8d646d6383"
  }, {
    "url": "manifest.webmanifest",
    "revision": "293a39eebd69588c2d8d520951e25188"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
