import{j as s,a5 as a}from"./index-DFfL1Yzl.js";const t=({className:o="w-16 h-16"})=>s.jsx(a,{className:o,size:64,background:"#2d2a45"});export{t as M};
